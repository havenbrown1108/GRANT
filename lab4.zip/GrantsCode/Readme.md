# Lab 1

This code causes GRANT to blink eyes with random colors and listen to IR input from the remote. Based on the input, 1 or 2, he will play a different song.

-   Button 1 - Megalovania
-   Button 2 - Mii Music
